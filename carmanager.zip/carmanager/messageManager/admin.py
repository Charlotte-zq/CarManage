from django.contrib import admin
from messageManager.models import *


class MessageAdmin(admin.ModelAdmin):
    list_display = ['id', 'id_send', 'title', 'content', 'id_reply', 'date', 'read_or_not']


class Tip_offAdmin(admin.ModelAdmin):
    list_display = ['id_stu', 'id_driver', 'id_vehicle', 'id_route', 'date', 'condition']


class NoticeAdmin(admin.ModelAdmin):
    list_display = ['id', 'id_send', 'title', 'content', 'date', 'id_receive']


admin.site.register(Message, MessageAdmin)
admin.site.register(Tip_off, Tip_offAdmin)
admin.site.register(Notice, NoticeAdmin)
