import json

from django.http import HttpResponse

import time
from messageManager.models import *
from usermanage.models import *
from routeManage.models import *


def send_notice(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        title = data_from.get('title')
        content = data_from.get('content')
        id_receive = data_from.get('id_receive')
        id_send = request.session['id']
        date = time.asctime(time.localtime(time.time()))

        if len(title) > 50:
            data = {'code': '标题长度过长'}
            return HttpResponse(json.dumps(data))
        if title.isspace:
            data = {'code': '标题不能为空白符'}
            return HttpResponse(json.dumps(data))

        if id_receive == "":
            notice = Notice(title=title, content=content, id_send=id_send, date=date, id_receive=None)
            notice.save()
        else:
            student = Student.objects.filter(id=id_receive).first()
            if student is None:
                data = {'code': '学生不存在'}
                return HttpResponse(json.dumps(data))
            else:
                notice = Notice(title=title, content=content, id_send=id_send, date=date, id_receive=id_receive)
                notice.save()
        data = {'date': date, 'code': '1'}
        return HttpResponse(json.dumps(data))


def delete_notice(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        title = data_from.get('title')
        date = data_from.get('date')
        notice = Notice.objects.filter(title=title, date=date).first()
        if notice is not None:
            notice.delete()
            notices = Notice.objects.filter()
            ret = {}
            for i in notices:
                ret[i.id] = [i.title, i.date]
            return HttpResponse(json.dumps(ret))


def check_notice_manager(request):
    notices = Notice.objects.filter()
    ret = {}
    for i in notices:
        ret[i.id] = [i.title, i.date]
    return HttpResponse(json.dumps(ret))


def check_notice_detail_manager(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        title = data_from.get('title')
        date = data_from.get('date')
        notice = Notice.objects.filter(title=title, date=date).first()
        if notice.id_receive is None:
            rec = "全部学生/家长"
        else:
            rec = notice.id_receive
        ret = {'content': notice.content, 'id_receive': rec}
        return HttpResponse(json.dumps(ret))


def get_notice(request):
    id = request.session['id']
    notices1 = Notice.objects.filter(id_receive=None)
    notices2 = Notice.objects.filter(id_receive=id)
    ret = {}
    for i in notices1:
        ret[i.id] = [i.title, i.date]
    for i in notices2:
        ret[i.id] = [i.title, i.date]
    return HttpResponse(json.dumps(ret))


def get_notice_detail(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        title = data_from['title']
        notice = Notice.objects.filter(title=title).first()
        ret = {'content': notice.content}
        return HttpResponse(json.dumps(ret))


def get_message(request):
    identity = request.session['identity']
    ret = {}
    if identity != 1:
        # 服务人员
        message = Message.objects.filter(id_reply=0, read_or_not=0)
        for i in message:
            ret[i.id] = {'id_send': i.id_send, 'title': i.title, 'content': i.content, 'date': i.date}
    else:
        # 学生
        message = Message.objects.filter(id_reply=id, read_or_not=0)
        for i in message:
            ret[i.id] = {'id_send': i.id_send, 'title': i.title, 'content': i.content, 'date': i.date}
    return HttpResponse(json.dumps(ret))


def check_message_manager(request):
    messages = Message.objects.filter()
    ret = {}
    for i in messages:
        if i.read_or_not == 0:
            if i.id_reply != '0':
                message_reply = Message.objects.filter(id=i.id_reply).first()
                ret[i.id] = [i.id_send, i.title, i.content, i.date, message_reply.content, message_reply.date]
            else:
                ret[i.id] = [i.id_send, i.title, i.content, i.date, "", ""]
    return HttpResponse(json.dumps(ret))


def manager_reply_message(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        title = data_from.get('title')
        date = data_from.get('date')
        id_send = data_from.get('id_send')
        content = data_from.get('content')

        message = Message.objects.filter(id_send=id_send, title=title, date=date).first()

        id = request.session['id']
        date_reply = time.asctime(time.localtime(time.time()))
        new_message = Message(id_send=id, content=content, date=date_reply, id_reply=message.id, read_or_not=1)
        new_message.save()
        message.id_reply = new_message.id
        message.save()

        messages = Message.objects.filter()
        ret = {}
        for i in messages:
            if i.read_or_not == 0:
                if i.id_reply != '0':
                    message_reply = Message.objects.filter(id=i.id_reply).first()
                    ret[i.id] = [i.id_send, i.title, i.content, i.date, message_reply.content, message_reply.date]
                else:
                    ret[i.id] = [i.id_send, i.title, i.content, i.date, "", ""]
        return HttpResponse(json.dumps(ret))


def check_tip_off(request):
    tip_offs = Tip_off.objects.filter()
    ret = {}
    for i in tip_offs:
        if i.condition == 1:
            con = "已处理"
        else:
            con = "未处理"
        ret[i.id] = [i.id_driver, i.id_stu, i.date, con]
    return HttpResponse(json.dumps(ret))


def check_tip_off_detail(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id_driver = data_from.get('id_driver')
        id_stu = data_from.get('id_stu')
        date = data_from.get('date')
        tip_off = Tip_off.objects.filter(id_driver=id_driver, id_stu=id_stu, date=date).first()
        if tip_off.condition == 1:
            con = "已处理"
        else:
            con = "未处理"
        ret = {'id_vehicle': tip_off.id_vehicle, 'id_route': tip_off.id_route, 'reason': tip_off.reason,
               'condition': con}
        return HttpResponse(json.dumps(ret))


def change_tip_off_condition(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id_driver = data_from.get('id_driver')
        id_stu = data_from.get('id_stu')
        date = data_from.get('date')
        new_condition = int(data_from.get('new_condition'))

        tip_off = Tip_off.objects.filter(id_driver=id_driver, id_stu=id_stu, date=date).first()
        tip_off.condition = new_condition
        tip_off.save()

        tip_offs = Tip_off.objects.filter()
        ret = {}
        for i in tip_offs:
            if i.condition == 1:
                con = "已处理"
            else:
                con = "未处理"
            ret[i.id] = [i.id_driver, i.id_stu, i.date, con]
        return HttpResponse(json.dumps(ret))


def delete_tip_off(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id_driver = data_from.get('id_driver')
        id_stu = data_from.get('id_stu')
        date = data_from.get('date')
        tip_off = Tip_off.objects.filter(id_driver=id_driver, id_stu=id_stu, date=date)
        tip_off.delete()

        tip_offs = Tip_off.objects.filter()
        ret = {}
        for i in tip_offs:
            if i.condition == 1:
                con = "已处理"
            else:
                con = "未处理"
            ret[i.id] = [i.id_driver, i.id_stu, i.date, con]
        return HttpResponse(json.dumps(ret))


def user_send_message(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id_send = request.session['id']
        title = data_from.get('title')
        content = data_from.get('content')
        date = time.asctime(time.localtime(time.time()))

        if len(title) > 50:
            data = {'code': '标题长度过长'}
            return HttpResponse(json.dumps(data))
        if title.isspace:
            data = {'code': '标题不能为空白符'}
            return HttpResponse(json.dumps(data))

        message = Message(id_send=id_send, title=title, content=content, id_reply=0, date=date, read_or_not=0)
        message.save()

        rets = {}
        messages = Message.objects.filter(id_send=id)
        for i in messages:
            title = i.title
            content = i.content
            date = i.date
            ret_message = Message.objects.filter(id_reply=i.id).first()
            if ret_message is not None:
                ret_content = ret_message.content
                ret_date = ret_message.date
                ret = [title, content, date, ret_content, ret_date]
                rets[i.id] = ret
            else:
                ret = [title, content, date, "", ""]
                rets[i.id] = ret
        return HttpResponse(json.dumps(rets))


def send_tip_off(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id_stu = request.session['id']
        id_driver = data_from.get('id_driver')
        id_vehicle = data_from.get('id_vehicle')
        id_route = data_from.get('id_route')
        reason = data_from.get('reason')
        date = time.asctime(time.localtime(time.time()))

        if id_driver.isdigit():
            driver_test = Driver.objects.filter(id=id_driver).first()
        else:
            driver_test = Driver.objects.filter(name=id_driver).first()

        vehicle_test = Vehicle.objects.filter(id=id_vehicle).first()
        route_test = Site.objects.filter(id_route=id_route).first()

        if driver_test is None:
            data = {'code': '司机不存在'}
        elif vehicle_test is None:
            data = {'code': '该车辆不存在'}
        elif route_test is None:
            data = {'code': '路线不存在'}
        else:
            tip_off = Tip_off(id_stu=id_stu, id_driver=id_driver, id_vehicle=id_vehicle, id_route=id_route, date=date,
                              reason=reason, condition=0)
            tip_off.save()
            data = {'code': '1'}
    else:
        data = {'code': '0'}
    return HttpResponse(json.dumps(data))


def check_user_feedback(request):
    id = request.session['id']
    rets = {}
    messages = Message.objects.filter(id_send=id)
    for i in messages:
        title = i.title
        content = i.content
        date = i.date
        ret_message = Message.objects.filter(id_reply=i.id).first()
        if ret_message is not None:
            ret_content = ret_message.content
            ret_date = ret_message.date
            ret = [title, content, date, ret_content, ret_date]
            rets[i.id] = ret
        else:
            ret = [title, content, date, "", ""]
            rets[i.id] = ret
    return HttpResponse(json.dumps(rets))
