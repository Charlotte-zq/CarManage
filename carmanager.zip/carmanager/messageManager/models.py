from django.db import models


class Message(models.Model):
    id_send = models.CharField(max_length=15)   # 发送人id号
    title = models.CharField(max_length=100, null=True)
    content = models.TextField()
    id_reply = models.CharField(max_length=15)  # 如果是用户信息，id_reply是回复该信息的消息id，如果是管理员信息，id_reply是回复的消息的id
    read_or_not = models.IntegerField()
    date = models.CharField(max_length=64)


class Tip_off(models.Model):
    id_stu = models.CharField(max_length=15)
    id_driver = models.CharField(max_length=15)
    id_vehicle = models.CharField(max_length=10)
    id_route = models.IntegerField()
    reason = models.CharField(max_length=512, null=True)
    date = models.CharField(max_length=64)
    condition = models.IntegerField(null=True)


class Notice(models.Model):
    id_send = models.CharField(max_length=15)
    title = models.CharField(max_length=100)
    content = models.TextField()
    date = models.CharField(max_length=64)
    id_receive = models.CharField(max_length=15, null=True)
