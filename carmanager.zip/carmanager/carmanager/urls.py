"""carmanager URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.template.defaulttags import url
from django.urls import path
from django.views.generic import TemplateView

from usermanage.views import *
from routeManage.views import *
from messageManager.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', TemplateView.as_view(template_name="index.html")),

    path('login/', login, name='login'),
    path('register/', register, name='register'),
    path('lgout/', lgout, name='lgout'),
    path('change_user_info/', change_user_info, name='change_user_info'),
    path('check_user_info/', check_user_info, name='check_user_info'),
    path('change_user_password/', change_user_password, name='change_user_password'),

    path('add_driver/', add_driver, name='add_driver'),
    path('delete_driver/', delete_driver, name='delete_driver'),
    path('change_driver_info/', change_driver_info, name='change_driver_info'),
    path('check_driver_info/', check_driver_info, name='check_driver_info'),
    path('check_driver_info_detail/', check_driver_info_detail, name='check_driver_info_detail'),

    path('add_vehicle/', add_vehicle, name='add_vehicle'),
    path('change_vehicle_info/', change_vehicle_info, name='change_vehicle_info'),
    path('check_vehicle_info/', check_vehicle_info, name='check_vehicle_info'),
    path('check_vehicle_info_detail/', check_vehicle_info_detail, name='check_vehicle_info_detail'),
    path('delete_vehicle/', delete_vehicle, name='delete_vehicle'),

    path('delete_route/', delete_route, name='delete_route'),
    path('add_route/', add_route, name='add_route'),
    path('change_route_info/', change_route_info, name='change_route_info'),
    path('check_route_user/', check_route_user, name='check_route_user'),
    path('check_route_manager/', check_route_manager, name='check_route_manager'),
    path('check_route_detail/', check_route_detail, name='check_route_detail'),
    path('search_route_keyword/', search_route_keyword, name='search_route_keyword'),
    path('add_record/', add_record, name='add_record'),

    path('delete_record/', delete_record, name='delete_record'),
    path('change_record/', change_record, name='change_record'),
    path('check_record/', check_record, name='check_record'),
    path('check_record_detail/', check_record_detail, name='check_record_detail'),
    path('check_record_start/', check_record_start, name='check_record_start'),
    path('check_record_end/', check_record_end, name='check_record_end'),

    path('send_notice/', send_notice, name='send_notice'),
    path('delete_notice/', delete_notice, name='delete_notice'),
    path('get_notice/', get_notice, name='get_notice'),
    path('check_notice_manager/', check_notice_manager, name='check_notice_manager'),
    path('check_notice_detail_manager/', check_notice_detail_manager, name='check_notice_detail_manager'),
    path('get_notice_detail/', get_notice_detail, name='get_notice_detail'),
    path('user_send_message/', user_send_message, name='user_send_message'),
    path('get_message/', get_message, name='get_message'),
    path('check_message_manager/', check_message_manager, name='check_message_manager'),
    path('manager_reply_message/', manager_reply_message, name='manager_reply_message'),

    path('send_tip_off/', send_tip_off, name='send_tip_off'),
    path('check_user_feedback/', check_user_feedback, name='check_user_feedback'),
    path('check_tip_off/', check_tip_off, name='check_tip_off'),
    path('check_tip_off_detail/', check_tip_off_detail, name='check_tip_off_detail'),
    path('change_tip_off_condition/', change_tip_off_condition, name='change_tip_off_condition'),
    path('delete_tip_off/', delete_tip_off, name='delete_tip_off')
]
