from django.contrib import admin
from usermanage.models import *


class StudentAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'tel', 'password', 'email', 'address']


class ManagerAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'tel', 'password', 'identity']


class DriverAdmin(admin.ModelAdmin):
    list_display = ['id', 'id_card', 'condition', 'name', 'tel', 'gender', 'age', 'date_time']


admin.site.register(Student, StudentAdmin)
admin.site.register(Manager, ManagerAdmin)
admin.site.register(Driver, DriverAdmin)