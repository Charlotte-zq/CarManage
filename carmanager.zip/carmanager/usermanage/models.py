from django.db import models


class Student(models.Model):
    id = models.CharField(max_length=15, primary_key=True)
    password = models.CharField(max_length=20)
    tel = models.CharField(max_length=15)
    name = models.CharField(max_length=64)
    email = models.CharField(max_length=64, null=True)
    address = models.CharField(max_length=64, null=True)


class Manager(models.Model):
    id = models.CharField(max_length=15, primary_key=True)
    password = models.CharField(max_length=20)
    tel = models.CharField(max_length=15)
    name = models.CharField(max_length=64)
    identity = models.IntegerField()


class Driver(models.Model):
    id = models.CharField(max_length=15, primary_key=True)
    id_card = models.CharField(max_length=20)
    condition = models.IntegerField()
    name = models.CharField(max_length=64)
    tel = models.CharField(max_length=15)
    gender = models.IntegerField()
    age = models.IntegerField()
    date_time = models.CharField(max_length=15)