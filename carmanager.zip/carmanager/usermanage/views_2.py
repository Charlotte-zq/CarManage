from django.core.serializers import json
from django.http import HttpResponse
from django.shortcuts import render

from usermanage.models import *


def home(request):
    username = ''
    if request.session.get('username'):
        username = request.session['username']
    message = 'lab3!!!'
    return render(request, 'home.html', {'username': username, 'message': message})


def register(request):
    if request.method == 'POST':
        new_identity = request.POST.get('identity')
        new_id = request.POST.get('id')
        new_tel = request.POST.get('tel')
        new_password1 = request.POST.get('password1')
        new_password2 = request.POST.get('password2')
        new_name = request.POST.get('name')

        if new_identity == '1':
            user = Student.objects.filter(id=new_id)
            if user.exists():
                data = [{'code': '2'}]
                return HttpResponse(json.dumps(data))
            else:
                if new_password2 != new_password1:
                    data = [{'code': '3'}]
                    return HttpResponse(json.dumps(data))
                else:
                    new_student = Student()
                    new_student.name = new_name
                    new_student.password = new_password1
                    new_student.tel = new_tel
                    new_student.id = new_id
                    new_student.save()
                    data = [{'code': '1'}]
                    return HttpResponse(json.dumps(data))
        else:
            userinfo = Manager.objects.filter(id=new_id)
            if userinfo.exists():
                data = [{'code': '2'}]
                return HttpResponse(json.dumps(data))
            else:
                if new_password2 != new_password1:
                    data = [{'code': '3'}]
                    return HttpResponse(json.dumps(data))
                else:
                    new_manager = Manager()
                    new_manager.name = new_name
                    new_manager.password = new_password1
                    new_manager.tel = new_tel
                    new_manager.id = new_id
                    new_manager.identity = int(new_identity)
                    new_manager.save()
                    data = [{'code': '1'}]
                    return HttpResponse(json.dumps(data))
    else:
        data = [{'code': '4'}]
        return HttpResponse(json.dumps(data))


def login(request):
    if request.method == 'POST':
        user_info = request.POST.get('id')
        password = request.POST.get('password')
        vcode = request.POST.get('vcode')

        if len(user_info) == 11:
            user1 = Student.objects.filter(tel=user_info).first()
            user2 = Manager.objects.filter(tel=user_info).first()
            if user1 is not None:
                if user1.password == password:
                    request.session['id'] = user1.id
                    request.session['name'] = user1.name
                    request.session['tel'] = user1.tel
                    request.session['password'] = user1.password
                    request.session['identity'] = 1
                    if vcode == 'test':
                        data = [{'code': '1'}]
                        return HttpResponse(json.dumps(data))
                    else:
                        data = [{'code': '2'}]
                        return HttpResponse(json.dumps(data))
                else:
                    data = [{'code': '3'}]
                    return HttpResponse(json.dumps(data))
            elif user2 is not None:
                if user2.password == password:
                    request.session['id'] = user2.id
                    request.session['name'] = user2.name
                    request.session['tel'] = user2.tel
                    request.session['password'] = user2.password
                    request.session['identity'] = user2.identity
                    if vcode == 'test':
                        data = [{'code': '1'}]
                        return HttpResponse(json.dumps(data))
                    else:
                        data = [{'code': '2'}]
                        return HttpResponse(json.dumps(data))
                else:
                    data = [{'code': '3'}]
                    return HttpResponse(json.dumps(data))
            else:
                data = [{'code': '4'}]
                return HttpResponse(json.dumps(data))
        elif len(user_info) == 8:
            user1 = Student.objects.filter(id=user_info).first()
            user2 = Manager.objects.filter(id=user_info).first()
            if user1 is not None:
                if user1.password == password:
                    request.session['id'] = user1.id
                    request.session['name'] = user1.name
                    request.session['tel'] = user1.tel
                    request.session['password'] = user1.password
                    request.session['identity'] = 1
                    if vcode == 'test':
                        data = [{'code': '1'}]
                        return HttpResponse(json.dumps(data))
                    else:
                        data = [{'code': '2'}]
                        return HttpResponse(json.dumps(data))
                else:
                    data = [{'code': '3'}]
                    return HttpResponse(json.dumps(data))
            elif user2 is not None:
                if user2.password == password:
                    request.session['id'] = user2.id
                    request.session['name'] = user2.name
                    request.session['tel'] = user2.tel
                    request.session['password'] = user2.password
                    request.session['identity'] = user2.identity
                    if vcode == 'test':
                        data = [{'code': '1'}]
                        return HttpResponse(json.dumps(data))
                    else:
                        data = [{'code': '2'}]
                        return HttpResponse(json.dumps(data))
                else:
                    data = [{'code': '3'}]
                    return HttpResponse(json.dumps(data))
            else:
                data = [{'code': '4'}]
                return HttpResponse(json.dumps(data))
    else:
        data = [{'code': '5'}]
        return HttpResponse(json.dumps(data))


def logout(request):
    request.session.flush()
    return render(request, 'login.html', {'message': '注销成功'})


def delete_driver(request):
    if request.method == 'POST':
        driver_id = request.POST.get('id')
        driver = Driver.objects.get(id=driver_id)
        driver.delete()
        return render(request, 'home.html', {'message': '删除成功'})
    else:
        return render(request, 'delete_driver.html', {'message': '请选择司机'})


def add_driver(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        gender = request.POST.get('gender')
        age = request.POST.get('age')
        id_card = request.POST.get('id_card')
        id = request.POST.get('id')
        tel = request.POST.get('tel')
        time = request.POST.get('time')
        condition = request.POST.get('condition')

        driver = Driver.objects.filter(id=id).first()
        if driver is None:
            driver = Driver(id=id, id_card=id_card, condition=int(condition), name=name, tel=tel, gender=int(gender), age=int(age), date_time=time)
            driver.save()
            return render(request, 'home.html', {'message': '添加成功'})
        else:
            return render(request, 'home.html', {'message': '该司机已存在'})
    else:
        return render(request, 'add_driver.html', {'message': '请填写信息'})


def change_driver_info(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        gender = request.POST.get('gender')
        age = request.POST.get('age')
        id = request.POST.get('id')
        id_card = request.POST.get('id_card')
        tel = request.POST.get('tel')
        time = request.POST.get('time')
        condition = request.POST.get('condition')

        driver = Driver.objects.filter(id=id).first()
        if driver is not None:
            driver.name = name
            driver.gender = gender
            driver.age = age
            driver.id_card = id_card
            driver.id = id
            driver.tel = tel
            driver.date_time = time
            driver.condition = condition
            driver.save()
            return render(request, 'home.html', {'message': '修改成功'})
        else:
            return render(request, 'home.html', {'message': '该司机不存在'})
    else:
        return render(request, 'change_driver_info.html', {'message': '请填写信息'})


def change_user_info(request):
    if request.method == 'POST':
        if request.session.get('id'):
            id = request.session['id']
            user1 = Student.objects.filter(id=id).first()
            user2 = Manager.objects.filter(id=id).first()
            if user1 is not None:
                new_tel = request.POST.get('tel')
                new_password = request.POST.get('password')
                new_name = request.POST.get('name')
                user1.tel = new_tel
                user1.name = new_name
                user1.password = new_password
                user1.save()
                return render(request, 'home.html', {'message': '修改成功'})
            else:
                new_identity = request.POST.get('identity')
                new_tel = request.POST.get('tel')
                new_password = request.POST.get('password')
                new_name = request.POST.get('name')
                user2.tel = new_tel
                user2.identity = new_identity
                user2.name = new_name
                user2.password = new_password
                user2.save()
                return render(request, 'home.html', {'message': '修改成功'})
        else:
            return render(request, 'home.html', {'message': 'error'})
    else:
        return render(request, 'home.html', {'message': '请填写信息'})


def check_user_info(request):
    if request.session.get('id'):
        id = request.session['id']
        name = request.session['name']
        tel = request.session['tel']
        password = request.session['password']
        identity = request.session['identity']
        if identity == 1:
            data = [{'id': id, 'name': name, 'tel': tel, 'password': password}]
            return HttpResponse(json.dumps(data))
            # return render(request, 'check_user_info.html', {'id': id, 'name': name, 'tel': tel, 'password': password})
        else:
            data = [{'id': id, 'name': name, 'tel': tel, 'password': password, 'identity': identity}]
            return HttpResponse(json.dumps(data))
            # return render(request, 'check_user_info.html', {'id': id, 'name': name, 'tel': tel, 'password': password, 'identity': identity})
    else:
        data = [{'data': 'none'}]
        return HttpResponse(json.dumps(data))
        # return render(request, 'home.html', {'message': '请登录'})


def check_driver_info(request):
    driver = Driver.objects.filter()
    return HttpResponse(json.dumps(driver))
    # return render(request, 'check_driver_info.html', {'List': driver})

