from django.http import HttpResponse

from usermanage.models import *
import json


def register(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        new_identity = data_from.get('identity')
        new_id = data_from.get('id')
        new_tel = data_from.get('tel')
        new_password1 = data_from.get('password1')
        new_password2 = data_from.get('password2')
        new_name = data_from.get('name')

        if new_identity == '1':
            user = Student.objects.filter(id=new_id)
            if user.exists():
                data = {'code': '用户已存在'}
                return HttpResponse(json.dumps(data))
            else:
                if len(new_id) != 8:
                    data = {'code': '学号长度不正确'}
                    return HttpResponse(json.dumps(data))
                elif not str(new_id).isdigit():
                    data = {'code': '学号不全为数字'}
                    return HttpResponse(json.dumps(data))
                elif len(new_tel) != 11:
                    data = {'code': '手机号长度不正确'}
                    return HttpResponse(json.dumps(data))
                elif not new_tel.isdigit():
                    data = {'code': '手机号不全为数字'}
                    return HttpResponse(json.dumps(data))
                elif new_name.isspace():
                    data = {'code': '姓名不能为空白符'}
                    return HttpResponse(json.dumps(data))
                elif new_password2 != new_password1:
                    data = {'code': '两次密码输入不一致'}
                    return HttpResponse(json.dumps(data))
                else:
                    new_student = Student()
                    new_student.name = new_name
                    new_student.password = new_password1
                    new_student.tel = new_tel
                    new_student.id = new_id
                    new_student.save()

                    request.session['id'] = new_id
                    request.session['name'] = new_name
                    request.session['tel'] = new_tel
                    request.session['password'] = new_password1
                    request.session['identity'] = 1
                    request.session['email'] = None
                    request.session['address'] = None
                    data = {'code': '1', 'identity': '1'}
                    return HttpResponse(json.dumps(data))
        else:
            userinfo = Manager.objects.filter(id=new_id)
            if userinfo.exists():
                data = {'code': '用户已存在'}
                return HttpResponse(json.dumps(data))
            else:
                if len(new_id) != 8:
                    data = {'code': '工号长度不正确'}
                    return HttpResponse(json.dumps(data))
                elif not str(new_id).isalnum():
                    data = {'code': '工号不全为数字或字母'}
                    return HttpResponse(json.dumps(data))
                elif len(new_tel) != 11:
                    data = {'code': '手机号长度不正确'}
                    return HttpResponse(json.dumps(data))
                elif not new_tel.isdigit():
                    data = {'code': '手机号不全为数字'}
                    return HttpResponse(json.dumps(data))
                elif new_password2 != new_password1:
                    data = {'code': '两次密码输入不一致'}
                    return HttpResponse(json.dumps(data))
                else:
                    new_manager = Manager()
                    new_manager.name = new_name
                    new_manager.password = new_password1
                    new_manager.tel = new_tel
                    new_manager.id = new_id
                    new_manager.identity = int(new_identity)
                    new_manager.save()
                    request.session['id'] = new_id
                    request.session['name'] = new_name
                    request.session['tel'] = new_tel
                    request.session['password'] = new_password1
                    request.session['identity'] = int(new_identity)
                    data = {'code': '1', 'identity': new_identity}
                    return HttpResponse(json.dumps(data))


def login(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        user_info = data_from.get('id')
        password = data_from.get('password')

        if len(user_info) == 11:
            user1 = Student.objects.filter(tel=user_info).first()
            user2 = Manager.objects.filter(tel=user_info).first()
            if user1 is not None:
                if user1.password == password:
                    request.session['id'] = user1.id
                    request.session['name'] = user1.name
                    request.session['tel'] = user1.tel
                    request.session['password'] = user1.password
                    request.session['identity'] = 1
                    data = {'code': '1', 'identity': '1'}
                    return HttpResponse(json.dumps(data))
                else:
                    data = {'code': '密码错误'}
                    return HttpResponse(json.dumps(data))
            elif user2 is not None:
                if user2.password == password:
                    request.session['id'] = user2.id
                    request.session['name'] = user2.name
                    request.session['tel'] = user2.tel
                    request.session['password'] = user2.password
                    request.session['identity'] = user2.identity
                    data = {'code': '1', 'identity': user2.identity}
                    return HttpResponse(json.dumps(data))
                else:
                    data = {'code': '密码错误'}
                    return HttpResponse(json.dumps(data))
            else:
                data = {'code': '用户不存在'}
                return HttpResponse(json.dumps(data))
        elif len(user_info) == 8:
            user1 = Student.objects.filter(id=user_info).first()
            user2 = Manager.objects.filter(id=user_info).first()
            if user1 is not None:
                if user1.password == password:
                    request.session['id'] = user1.id
                    request.session['name'] = user1.name
                    request.session['tel'] = user1.tel
                    request.session['password'] = user1.password
                    request.session['identity'] = 1
                    request.session['email'] = user1.email
                    request.session['address'] = user1.address
                    data = {'code': '1', 'identity': '1'}
                    return HttpResponse(json.dumps(data))
                else:
                    data = {'code': '密码错误'}
                    return HttpResponse(json.dumps(data))
            elif user2 is not None:
                if user2.password == password:
                    request.session['id'] = user2.id
                    request.session['name'] = user2.name
                    request.session['tel'] = user2.tel
                    request.session['password'] = user2.password
                    request.session['identity'] = user2.identity
                    data = {'code': '1', 'identity': user2.identity}
                    return HttpResponse(json.dumps(data))
                else:
                    data = {'code': '密码错误'}
                    return HttpResponse(json.dumps(data))
            else:
                data = {'code': '用户不存在'}
                return HttpResponse(json.dumps(data))
        else:
            data = {'code': '用户不存在'}
            return HttpResponse(json.dumps(data))


def lgout(request):
    request.session.flush()
    data = {'code': '退出成功'}
    return HttpResponse(json.dumps(data))


def change_user_password(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        if request.session.get('id'):
            id = request.session['id']
            old_password = data_from.get('old_password')
            new_password1 = data_from.get('new_password1')
            new_password2 = data_from.get('new_password2')
            password = request.session.get('password')
            user1 = Student.objects.filter(id=id).first()
            user2 = Manager.objects.filter(id=id).first()
            if user1 is not None:
                if old_password == password and new_password1 == new_password2:
                    user1.password = new_password1
                    user1.save()
                    request.session['password'] = new_password1
                    data = {'code': '1'}
                elif old_password != password:
                    data = {'code': '旧密码错误'}
                elif new_password1 != new_password2:
                    data = {'code': '两次密码不一致'}
            elif user2 is not None:
                if old_password == password and new_password1 == new_password2:
                    user2.password = new_password1
                    user2.save()
                    request.session['password'] = new_password1
                elif old_password != password:
                    data = {'code': '旧密码错误'}
                elif new_password1 != new_password2:
                    data = {'code': '两次密码不一致'}
    else:
        data = {'code': '请输入信息'}
    return HttpResponse(json.dumps(data))


def change_user_info(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        if request.session.get('id'):
            id = request.session['id']
            user1 = Student.objects.filter(id=id).first()
            if user1 is not None:
                new_tel = data_from.get('tel')
                new_email = data_from.get('email')
                new_address = data_from.get('address')
                if len(new_tel) != 11:
                    data = {'code': '手机号长度不正确'}
                    return HttpResponse(json.dumps(data))
                elif not new_tel.isdigit():
                    data = {'code': '手机号不全为数字'}
                    return HttpResponse(json.dumps(data))
                elif not "@" in new_email:
                    data = {'code': '邮箱地址不正确'}
                    return HttpResponse(json.dumps(data))
                elif new_address.isspace():
                    data = {'code': '地址不能为空白符'}
                    return HttpResponse(json.dumps(data))
                user1.tel = new_tel
                user1.email = new_email
                user1.address = new_address
                user1.save()
                request.session['tel'] = new_tel
                request.session['email'] = new_email
                request.session['address'] = new_address
                data = {'tel': new_tel, 'email': new_email, 'address': new_address, 'code': '1'}
                return HttpResponse(json.dumps(data))
    else:
        data = {'code': '0'}
        return HttpResponse(json.dumps(data))


def check_user_info(request):
    if request.session.get('id'):
        id = request.session['id']
        name = request.session['name']
        tel = request.session['tel']
        password = request.session['password']
        identity = request.session['identity']
        email = request.session['email']
        address = request.session['address']
        if identity == 1:
            data = {'id': id, 'tel': tel, 'password': password, 'name': name, 'email': email, 'address': address}
            return HttpResponse(json.dumps(data))
    else:
        data = {'data': 'none'}
        return HttpResponse(json.dumps(data))


def delete_driver(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        driver_id = data_from.get('id')
        driver = Driver.objects.get(id=driver_id)
        driver.delete()

        drivers = Driver.objects.filter()
        ret = {}
        for i in drivers:
            if i.condition == 1:
                con = "在职"
            else:
                con = "停职"
            ret[i.id] = [i.name, i.id, con]
        return HttpResponse(json.dumps(ret))


def add_driver(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        name = data_from.get('name')
        gender = data_from.get('gender')
        age = data_from.get('age')
        id_card = data_from.get('id_card')
        id = data_from.get('id')
        tel = data_from.get('tel')
        time = data_from.get('time')
        condition = data_from.get('condition')

        age = str(age)
        if not age.isdigit():
            data = {'code': '年龄不合法'}
            return HttpResponse(json.dumps(data))
        if int(age) < 18:
            data = {'code': '年龄不合法'}
            return HttpResponse(json.dumps(data))

        driver = Driver.objects.filter(id=id).first()
        driver2 = Driver.objects.filter(name=name).first()
        print(driver)
        print(driver2)
        if driver is None and driver2 is None:
            driver = Driver(id=id, id_card=id_card, condition=int(condition), name=name, tel=tel, gender=int(gender), age=int(age), date_time=time)
            driver.save()
            if condition == 1:
                con = "在职"
            else:
                con = "停职"
            data = {'condition': con, 'code': '1'}
            return HttpResponse(json.dumps(data))
        else:
            data = {'code': '司机已存在'}
            print(data)
            return HttpResponse(json.dumps(data))


def change_driver_info(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        name = data_from.get('name')
        gender = data_from.get('gender')
        age = data_from.get('age')
        id = data_from.get('id')
        tel = data_from.get('tel')
        time = data_from.get('time')
        condition = data_from.get('condition')

        age = str(age)
        if not age.isdigit():
            data = {'code': '年龄不合法'}
            return HttpResponse(json.dumps(data))
        if int(age) < 18:
            data = {'code': '年龄不合法'}
            return HttpResponse(json.dumps(data))

        driver = Driver.objects.filter(id=id).first()
        if driver is not None:
            driver.name = name
            driver.gender = gender
            driver.age = int(age)
            driver.tel = tel
            driver.date_time = time
            driver.condition = condition
            driver.save()

            drivers = Driver.objects.filter()
            ret = {}
            for i in drivers:
                if i.condition == 1:
                    con = "在职"
                else:
                    con = "停职"
                ret[i.id] = [i.name, i.id, con]
            ret['code'] = '1'
            return HttpResponse(json.dumps(ret))


def check_driver_info(request):
    drivers = Driver.objects.filter()
    ret = {}
    for i in drivers:
        if i.condition == 1:
            con = "在职"
        else:
            con = "停职"
        ret[i.id] = [i.name, i.id, con]
    return HttpResponse(json.dumps(ret))


def check_driver_info_detail(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id = data_from.get('id')
        driver = Driver.objects.filter(id=id).first()
        if driver.condition == 1:
            con = "在职"
        else:
            con = "停职"
        if driver.gender == 1:
            sex = "男"
        else:
            sex = "女"
        ret = {'id': id, 'id_card': driver.id_card, 'name': driver.name, 'tel': driver.tel, 'gender': sex,
               'age': driver.age, 'date': driver.date_time, 'condition': con}
        return HttpResponse(json.dumps(ret))
