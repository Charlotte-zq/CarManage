import json

from django.core import serializers
from django.http import HttpResponse

from routeManage.models import *
from usermanage.models import *


def add_vehicle(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        new_id = data_from.get('id')
        new_type = data_from.get('type')
        new_status = data_from.get('status')
        new_mileage = data_from.get('mileage')
        new_check_time = data_from.get('check_time')
        new_capacity = data_from.get('capacity')

        new_capacity = str(new_capacity)
        new_mileage = str(new_mileage)

        if new_id.isspace():
            data = {'code': '车牌号不能为空白符'}
            return HttpResponse(json.dumps(data))
        elif len(str(id)) != 7:
            data = {'code': '车牌号长度不正确'}
            return HttpResponse(json.dumps(data))

        try:
            new_capacity = int(new_capacity)
        except ValueError:
            data = {'code': '限载人数不符合要求'}
            return HttpResponse(json.dumps(data))
        try:
            new_mileage = float(new_mileage)
        except ValueError:
            data = {'code': '里程数不符合要求'}
            return HttpResponse(json.dumps(data))

        new_vehicle = Vehicle.objects.filter(id=new_id).first()
        if new_vehicle is not None:
            data = {'code': '车辆已存在'}
            return HttpResponse(json.dumps(data))
        elif not new_mileage >= 0:
            data = {'code': '里程数错误'}
            return HttpResponse(json.dumps(data))
        elif not new_capacity > 0:
            data = {'code': '限载人数错误'}
            return HttpResponse(json.dumps(data))
        else:
            new_vehicle = Vehicle(id=new_id, type=new_type, status=new_status, mileage=new_mileage,
                                  check_time=new_check_time, capacity=new_capacity)
            new_vehicle.save()
            data = {'code': '1'}
            return HttpResponse(json.dumps(data))
    else:
        data = {'code': '0'}
        return HttpResponse(json.dumps(data))


def change_vehicle_info(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id = data_from.get('id')
        new_type = data_from.get('type')
        new_status = data_from.get('status')
        new_mileage = data_from.get('mileage')
        new_check_time = data_from.get('check_time')
        new_capacity = data_from.get('capacity')

        new_capacity = str(new_capacity)
        new_mileage = str(new_mileage)

        try:
            new_capacity = int(new_capacity)
        except ValueError:
            data = {'code': '限载人数不符合要求'}
            return HttpResponse(json.dumps(data))
        try:
            new_mileage = float(new_mileage)
        except ValueError:
            data = {'code': '里程数不符合要求'}
            return HttpResponse(json.dumps(data))

        if not new_mileage >= 0:
            data = {'code': '里程数错误'}
            return HttpResponse(json.dumps(data))
        elif not new_capacity > 0:
            data = {'code': '限载人数错误'}
            return HttpResponse(json.dumps(data))

        vehicle = Vehicle.objects.filter(id=id).first()
        vehicle.id = id
        vehicle.type = new_type
        vehicle.status = new_status
        vehicle.mileage = new_mileage
        vehicle.check_time = new_check_time
        vehicle.capacity = new_capacity
        vehicle.save()
        # ret = {'id': id, 'type': new_type, 'status': new_status, 'mileage': vehicle.mileage,
        #      'check_time': new_check_time, 'capacity': vehicle.capacity, 'code': '1'}
        # return HttpResponse(json.dumps(ret))
        vehicles = Vehicle.objects.filter()
        ret = {}
        for i in vehicles:
            ret[i.id] = [i.id, i.type]
        ret['code'] = '1'
        return HttpResponse(json.dumps(ret))


def check_vehicle_info(request):
    vehicles = Vehicle.objects.filter()
    ret = {}
    for i in vehicles:
        ret[i.id] = [i.id, i.type]
    return HttpResponse(json.dumps(ret))


def check_vehicle_info_detail(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id = data_from.get('id')
        vehicle = Vehicle.objects.filter(id=id).first()
        ret = {'id': id, 'type': vehicle.type, 'status': vehicle.status, 'mileage': vehicle.mileage,
               'check_time': vehicle.check_time, 'capacity': vehicle.capacity}
        return HttpResponse(json.dumps(ret))


def delete_vehicle(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id = data_from.get('id')
        vehicle = Vehicle.objects.filter(id=id).first()
        vehicle.delete()
        vehicles = Vehicle.objects.filter()
        ret = {}
        for i in vehicles:
            ret[i.id] = [i.id, i.type]
        return HttpResponse(json.dumps(ret))


def delete_route(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        route_id = int(data_from.get('route_id'))
        Site.objects.filter(id_route=route_id).delete()
        ret = {}
        route_ids = Site.objects.values("id_route").order_by('id_route')
        route_ids = route_ids.distinct()
        for i in route_ids:
            ret[i] = i
        return HttpResponse(json.dumps(ret))


def add_route(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        route_id = int(data_from.get('route_id'))
        sites = data_from['sites']
        site = Site.objects.filter(id_route=route_id).first()
        if site is not None:
            data = {'code': '该路线已存在'}
            return HttpResponse(json.dumps(data))
        else:
            for i in sites:
                site_name = i.get('name')
                site_test = Site.objects.filter(name=site_name).first()
                if site_test is not None:
                    data = {'code': '站点名存在重复'}
                    return HttpResponse(json.dumps(data))
            for i in range(len(sites)):
                site_name = sites[i].get('name')
                site = Site(name=site_name, id_route=route_id, position=(i + 1))
                site.save()
            data = {'code': '1'}
            return HttpResponse(json.dumps(data))


def change_route_info(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        route_id = int(data_from.get('route_id'))
        sites = data_from['sites']
        site_test = Site.objects.filter(id_route=route_id).first()
        if site_test is not None:
            Site.objects.filter(id_route=route_id).delete()

            for i in sites:
                site_name = i.get('name')
                site_test = Site.objects.filter(name=site_name).first()
                if site_test is not None:
                    data = {'code': '站点名' + site_test.name + '已存在'}
                    return HttpResponse(json.dumps(data))

            for i in range(len(sites)):
                site_name = sites[i].get('name')
                site = Site(name=site_name, id_route=route_id, position=(i + 1))
                site.save()
            data = {'code': '1'}
            return HttpResponse(json.dumps(data))
        else:
            data = {'code': '该路线不存在'}
            return HttpResponse(json.dumps(data))
    else:
        data = {'code': '0'}
        return HttpResponse(json.dumps(data))


def check_route_manager(request):
    ret = {}
    route_ids = Site.objects.values("id_route").order_by('id_route')
    route_ids = route_ids.distinct()
    for i in route_ids:
        ret[i.get('id_route')] = i.get('id_route')
    return HttpResponse(json.dumps(ret))


def check_route_user(request):
    ret = {}
    route_ids = Site.objects.values("id_route").order_by('id_route')
    route_ids = route_ids.distinct()
    for i in route_ids:
        sites = []
        sites_test = Site.objects.filter(id_route=i['id_route'])
        for j in sites_test:
            sites.append(j.name)
        ret[i['id_route']] = sites
    return HttpResponse(json.dumps(ret))


def check_route_detail(request):
    data_from = json.loads(request.body)
    ret = {}
    if request.method == 'POST':
        id = data_from.get('route_id')
        sites = Site.objects.filter(id_route=id).order_by('position')
        for i in sites:
            ret[i.position] = i.name
        return HttpResponse(json.dumps(ret))


def search_route_keyword(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        keyword = data_from.get('keyword')
        if keyword is not None:
            routes = {}
            if keyword.isdigit():
                sites = Site.objects.filter(id_route=int(keyword)).order_by('position')
                if sites.first() is not None:
                    names = []
                    for i in sites:
                        names.append(i.name)
                    routes[int(keyword)] = names
            else:
                sites = Site.objects.filter(name__contains=keyword)
                if sites.first() is not None:
                    route_ids = []
                    routes = {}
                    for i in sites:
                        route_ids.append(i.id_route)
                    for i in route_ids:
                        sites = Site.objects.filter(id_route=i).order_by('position')
                        names = []
                        for j in sites:
                            names.append(j.name)
                        routes[i] = names
            return HttpResponse(json.dumps(routes))


def add_record(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        new_id_vehicle = data_from.get('id_vehicle')
        new_id_route = data_from.get('id_route')
        new_date = data_from.get('date')
        new_id_driver = data_from.get('id_driver')
        new_start_or_end = data_from.get('start_or_end')
        driver = Driver.objects.filter(id=new_id_driver).first()
        route_test = Site.objects.filter(id_route=new_id_route).first()
        vehicle_test = Vehicle.objects.filter(id=new_id_vehicle).first()
        if route_test is None:
            data = {'code': '路线不存在'}
        elif vehicle_test is None:
            data = {'code': '车辆不存在'}
        elif driver is None:
            data = {'code': '司机不存在'}
        else:
            if driver.condition == 0:
                data = {'code': '司机已被停职'}
            elif vehicle_test.status == '0':
                data = {'code': '车辆不可用'}
            else:
                new_driver_name = driver.name

                new_record = Record(id_vehicle=new_id_vehicle, id_route=int(new_id_route), date=new_date,
                                    id_driver=new_id_driver,
                                    driver=new_driver_name, start_or_end=int(new_start_or_end))
                new_record.save()
                if int(new_start_or_end) == 1:
                    data = {'direction': '到校', 'code': '1'}
                else:
                    data = {'direction': '离校', 'code': '1'}
        return HttpResponse(json.dumps(data))


def delete_record(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id_route = data_from.get('id_route')
        date = data_from.get('date')
        direction = int(data_from.get('direction'))
        record = Record.objects.filter(id_route=id_route, date=date, start_or_end=direction).first()
        record.delete()

        records = Record.objects.filter()
        ret = {}
        for i in records:
            if i.start_or_end == 1:
                direction = "到校"
            else:
                direction = "离校"
            ret[i.id] = [i.id_route, i.date, direction]
        return HttpResponse(json.dumps(ret))


def change_record(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        new_id_vehicle = data_from.get('new_id_vehicle')
        new_id_route = data_from.get('new_id_route')
        new_date = data_from.get('new_date')
        new_id_driver = data_from.get('new_id_driver')
        new_start_or_end = data_from.get('new_start_or_end')

        old_id_vehicle = data_from.get('old_id_vehicle')
        old_id_route = data_from.get('old_id_route')
        old_date = data_from.get('old_date')
        old_id_driver = data_from.get('old_id_driver')
        old_start_or_end = data_from.get('old_start_or_end')

        record = Record.objects.filter(id_vehicle=old_id_vehicle, id_route=int(old_id_route), date=old_date,
                                       id_driver=old_id_driver,
                                       start_or_end=int(old_start_or_end)).first()

        route_test = Site.objects.filter(id_route=new_id_route).first()
        vehicle_test = Vehicle.objects.filter(id=new_id_vehicle).first()
        driver_test = Driver.objects.filter(id=new_id_driver).first()
        if route_test is None:
            ret = {'code': '路线不存在'}
        elif vehicle_test is None:
            ret = {'code': '车辆不存在'}
        elif driver_test is None:
            ret = {'code': '司机不存在'}
        else:
            if vehicle_test.status == '0':
                ret = {'code': '车辆不可用'}
            elif driver_test.condition == 0:
                ret = {'code': '司机已被停职'}
            else:
                record.id_vehicle = new_id_vehicle
                record.id_route = int(new_id_route)
                record.date = new_date
                record.id_driver = new_id_driver
                record.start_or_end = int(new_start_or_end)
                record.driver = driver_test.name
                record.save()

                records = Record.objects.filter()
                ret = {}
                for i in records:
                    if i.start_or_end == 1:
                        direction = "到校"
                    else:
                        direction = "离校"
                    ret[i.id] = [i.id_route, i.date, direction]
                ret['code'] = '1'
        return HttpResponse(json.dumps(ret))


def check_record(request):
    records = Record.objects.filter()
    ret = {}
    for i in records:
        if i.start_or_end == 1:
            direction = "到校"
        else:
            direction = "离校"
        ret[i.id] = [i.id_route, i.date, direction]
    return HttpResponse(json.dumps(ret))


def check_record_detail(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id_route = data_from.get('id_route')
        date = data_from.get('date')
        direction = data_from.get('direction')
        record = Record.objects.filter(id_route=id_route, date=date, start_or_end=int(direction)).first()
        if record.start_or_end == 1:
            tmp = "到校"
        else:
            tmp = "离校"
        ret = {'id_vehicle': record.id_vehicle, 'id_driver': record.id_driver, 'driver': record.driver,
               'direction': tmp}
        return HttpResponse(json.dumps(ret))


def check_record_start(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id = data_from.get('id')
        records = Record.objects.filter(id_route=id, start_or_end=1)
        records_return = {}
        for i in records:
            tmp = [i.date, i.id_vehicle, i.id_driver, i.driver]
            records_return[i.id] = tmp
        return HttpResponse(json.dumps(records_return))


def check_record_end(request):
    data_from = json.loads(request.body)
    if request.method == 'POST':
        id = data_from.get('id')
        records = Record.objects.filter(id_route=id, start_or_end=0)
        records_return = {}
        for i in records:
            tmp = [i.date, i.id_vehicle, i.id_driver, i.driver]
            records_return[i.id] = tmp
        return HttpResponse(json.dumps(records_return))
