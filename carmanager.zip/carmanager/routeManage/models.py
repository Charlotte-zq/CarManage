from django.db import models


class Site(models.Model):
    name = models.CharField(max_length=64, primary_key=True)
    id_route = models.IntegerField()
    position = models.IntegerField()


class Vehicle(models.Model):
    id = models.CharField(max_length=10, primary_key=True)
    type = models.CharField(max_length=64)
    status = models.CharField(max_length=64)
    mileage = models.FloatField()
    check_time = models.CharField(max_length=64)
    capacity = models.IntegerField()


class Record(models.Model):
    id_vehicle = models.CharField(max_length=64)
    id_route = models.IntegerField()
    date = models.CharField(max_length=64)
    id_driver = models.CharField(max_length=15)
    driver = models.CharField(max_length=64)
    start_or_end = models.IntegerField()
