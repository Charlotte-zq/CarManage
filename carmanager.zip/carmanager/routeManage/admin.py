from django.contrib import admin
from routeManage.models import *


class SiteAdmin(admin.ModelAdmin):
    list_display = ['name', 'id_route', 'position']


class VehicleAdmin(admin.ModelAdmin):
    list_display = ['id', 'type', 'status', 'mileage', 'check_time', 'capacity']


class RecordAdmin(admin.ModelAdmin):
    list_display = ['id_vehicle', 'id_route', 'date', 'id_driver', 'driver', 'start_or_end']


admin.site.register(Site, SiteAdmin)
admin.site.register(Vehicle, VehicleAdmin)
admin.site.register(Record, RecordAdmin)
